import json
import os
import datetime
import matplotlib.pyplot as plt
import torch
from torch.utils import data
import numpy as np
from sklearn.utils.multiclass import unique_labels
from sklearn.metrics import confusion_matrix

import matplotlib.pyplot as pl
from sklearn import metrics
# 相关库

def plot_matrix(confusion_matrix, labels_name, title=None, pic_name=None,thresh=0.8, axis_labels=None):
    # 清除
    plt.clf()
    # 标签名
    classes = labels_name
    # 标签的个数
    classNamber = 4  # 表情的数量
    pic_name = pic_name
    title1 = title
    # 在标签中的矩阵
    matrix_data = confusion_matrix

    # 按照像素显示出矩阵
    # plt.imshow(matrix_data, interpolation='nearest', cmap=plt.cm.Blues)
    plt.imshow(matrix_data, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title(title1)

    # 显示右边柱形图
    plt.colorbar()

    tick_marks = np.arange(len(classes))

    # 把xy轴上的数字改为标签名
    plt.xticks(tick_marks, classes)
    plt.yticks(tick_marks, classes)

    thresh = matrix_data.max() / 2.
    # iters = [[i,j] for i in range(len(classes)) for j in range((classes))]
    # ij配对，遍历矩阵迭代器
    iters = np.reshape([[[i, j] for j in range(classNamber)] for i in range(classNamber)], (confusion_matrix.size, 2))
    for i, j in iters:
        text_color = 'white' if (i == 0 and j == 0)  else 'black'
        plt.text(j, i, format(matrix_data[i, j]), va='center', ha='center', color=text_color, fontsize=16)  # 显示对应的数字

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    pic = os.path.join('./data/coco2017/', pic_name)
    plt.savefig(pic)

def plot_matrix_percent(confusion_matrix, labels_name, title=None, pic_name=None,thresh=0.8, axis_labels=None):

    plt.clf()
    classes = labels_name
    classNumber = len(classes)
    pic_name = pic_name
    title1 = title


    confusion_matrix_percentage = confusion_matrix / confusion_matrix.sum(axis=1)[:, np.newaxis]

    # plt.imshow(confusion_matrix_percentage, interpolation='nearest',cmap=plt.cm.Blues)
    plt.imshow(confusion_matrix_percentage, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title(title1)
    plt.colorbar()

    tick_marks = np.arange(classNumber)
    plt.xticks(tick_marks, classes)
    plt.yticks(tick_marks, classes)

    thresh = confusion_matrix.max() / 2.

    for i in range(classNumber):
        for j in range(classNumber):
            text_color = 'white' if (i == 0 and j == 0) else 'black'
            plt.text(j, i, f'{confusion_matrix_percentage[i, j] * 100:.2f}%', va='center', ha='center', color=text_color, fontsize=16)

    plt.ylabel('Ground Truth')
    plt.xlabel('Diagnostic Results')
    plt.tight_layout()

    pic = os.path.join('./data/coco2017/', pic_name)
    plt.savefig(pic)