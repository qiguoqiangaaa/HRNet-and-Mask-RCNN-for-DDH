import json
import os
import datetime
import matplotlib.pyplot as plt
import torch
from torch.utils import data
import numpy as np

import transforms
from model import HighResolutionNet,HighResolutionNet_48
from model import ResNet
from my_dataset_coco import CocoKeypoint
from train_utils import train_eval_utils as utils


os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"



def create_model(num_joints, load_pretrain_weights=True,base_channel=32):
    model = HighResolutionNet(base_channel=32, num_joints=num_joints)  # 32对应w32

    # load_pretrain_weights = True 则载入预训练权重
    if load_pretrain_weights:
        # 载入预训练模型权重
        # 链接:https://pan.baidu.com/s/1Lu6mMAWfm_8GGykttFMpVw 提取码:f43o
        weights_dict = torch.load("hrnet_w32.pth", map_location='cpu')
        # weights_dict = "./resnet34.pth"
        for k in list(weights_dict.keys()):
            # 如果载入的是imagenet权重，就删除无用权重（关键点检测不需要全连接层（fc/head））
            if ("head" in k) or ("fc" in k):
                del weights_dict[k]

            # 如果载入的是coco数据集的权重
            # 会检查权重字典中final_layer键对应的值（一般为模型最后一层的权重）的第一个维度（通常是关键点数量）是否与任务中需要的关键点数量相等
            # 如果不相等，则需要删除该权重
            if "final_layer" in k:
                if weights_dict[k].shape[0] != num_joints:
                    del weights_dict[k]

        missing_keys, unexpected_keys = model.load_state_dict(weights_dict, strict=False)   # 载入预训练模型权重
        # 如果目标模型有一个新的层，而预训练模型中并没有这个层的权重，则这个层的权重就是缺失的权重。
        # 将strict设为False，表示允许加载不完全匹配的权重。如果加载完成后存在缺失的权重，则会打印相应的missing_keys，即没有加载成功的权重键。
        if len(missing_keys) != 0:
            print("missing_keys: ", missing_keys)

    return model


def main(args):
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    print("Using {} device training.".format(device.type))

    # 用来保存coco_info的文件，每个epoch的结果会存储在其中
    # 文件名：result+当前时间，保存了10个mAP+loss+lr
    results_file = "results{}.txt".format(datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))

    # 载入字典person_keypoints.json
    with open(args.keypoints_path, "r") as f:
        person_kps_info = json.load(f)

    # 获取输入图片的高宽
    fixed_size = args.fixed_size
    # 热力图的高宽是输入原图的1/4
    heatmap_hw = (args.fixed_size[0] // 4, args.fixed_size[1] // 4)
    # 获取每个关键点的权重（kps_weights），每个关键点的权重不一样大
    kps_weights = np.array(person_kps_info["kps_weights"],
                           dtype=np.float32).reshape((args.num_joints,))

    # 训练和验证的数据增强
    data_transform = {
        "train": transforms.Compose([
            # 一定的概率截取上半身（upper_body_ids）或下半身（lower_body_ids）的关键点
            # transforms.HalfBody(0.3, person_kps_info["upper_body_ids"], person_kps_info["lower_body_ids"]),
            # 随机缩放(0.65, 1.35之间，随机旋转(-45度, 45度)之间
            transforms.AffineTransform(scale=(0.7, 1.3), rotation=(-30, 30), fixed_size=fixed_size),
            # 沿水平方向的随机翻转
            transforms.RandomHorizontalFlip(0.5, person_kps_info["flip_pairs"]),
            # 把GT提供的关键点信息转化为热图，训练计算损失时会使用到
            transforms.KeypointToHeatMap(heatmap_hw=heatmap_hw, gaussian_sigma=2, keypoints_weights=kps_weights),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ]),
        "val": transforms.Compose([
            # 尺度放大1.15倍，如果根据GT信息或者bounding box裁剪人，有些关键点可能会落在裁剪后的边缘
            # 为了避免这种情况，就把bounding box放大1.25倍
            transforms.AffineTransform(scale=(1, 1.2), fixed_size=fixed_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    }
    # 数据集路径*************************************************************************************
    data_root = args.data_path

    # load train data set
    # coco2017 -> annotations -> person_keypoints_train2017.json
    # my_dataset_coco中定义的CocoKeypoint，用于读取coco数据集
    # 实例化训练集
    train_dataset = CocoKeypoint(data_root, "train", transforms=data_transform["train"], fixed_size=args.fixed_size)
    print("train_dataset number:", len(train_dataset))

    # 注意这里的collate_fn是自定义的，因为读取的数据包括image和targets，不能直接使用默认的方法合成batch
    batch_size = args.batch_size
    nw = min([os.cpu_count(), batch_size if batch_size > 1 else 0, 8])  # number of workers
    print('Using %g dataloader workers' % nw)

    train_data_loader = data.DataLoader(train_dataset,
                                        batch_size=batch_size,
                                        shuffle=True,
                                        pin_memory=True,
                                        num_workers=nw,
                                        collate_fn=train_dataset.collate_fn)

    # load validation data set
    # coco2017 -> annotations -> person_keypoints_val2017.json
    val_dataset = CocoKeypoint(data_root, "val", transforms=data_transform["val"], fixed_size=args.fixed_size,
                               det_json_path=args.person_det)
    print("val_dataset number:", len(val_dataset))
    val_data_loader = data.DataLoader(val_dataset,
                                      batch_size=batch_size,
                                      shuffle=False,
                                      pin_memory=True,
                                      num_workers=nw,
                                      collate_fn=val_dataset.collate_fn)

    # create model
    model = create_model(num_joints=args.num_joints)
    # print(model)

    model.to(device)

    # define optimizer
    # 获取模型参数
    params = [p for p in model.parameters() if p.requires_grad]
    # 定义优化器
    optimizer = torch.optim.AdamW(params,
                                  lr=args.lr,
                                  weight_decay=args.weight_decay)

    scaler = torch.cuda.amp.GradScaler() if args.amp else None

    # learning rate scheduler
    # 每迭代到指定的epoch就进行学习率衰减
    lr_scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=args.lr_steps, gamma=args.lr_gamma)

    # 如果指定了上次训练保存的权重文件地址，则把训练好的参数都读取出来接着训练
    if args.resume != "":
        checkpoint = torch.load(args.resume, map_location='cpu')     # 读取最近一次权重的相关信息后载入
        model.load_state_dict(checkpoint['model'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
        args.start_epoch = checkpoint['epoch'] + 1
        if args.amp and "scaler" in checkpoint:
            scaler.load_state_dict(checkpoint["scaler"])
        print("the training process from epoch{}...".format(args.start_epoch))

    train_loss = []
    learning_rate = []
    val_map = []

    for epoch in range(args.start_epoch, args.epochs):
        # 训练集, printing every 50 iterations，返回平均损失和学习率
        mean_loss, lr = utils.train_one_epoch(model, optimizer, train_data_loader,
                                              device=device, epoch=epoch,
                                              print_freq=10, warmup=True,
                                              scaler=scaler)
        # 每训练一个epoch就返回这一轮的平均损失和学习率,用于绘图
        train_loss.append(mean_loss.item())
        learning_rate.append(lr)

        # update the learning rate
        lr_scheduler.step()

        # 验证集，返回相应的coco指标
        coco_info = utils.evaluate(model, val_data_loader, device=device,
                                   flip=True, flip_pairs=person_kps_info["flip_pairs"])

        # write into txt
        with open(results_file, "a") as f:
            # 写入最开始的result文件，写入的四位小数的数据，数据：coco指标+loss+lr，每一行都是一个epoch的信息
            result_info = [f"{i:.4f}" for i in coco_info + [mean_loss.item()]] + [f"{lr:.6f}"]
            txt = "epoch:{} {}".format(epoch, '  '.join(result_info))
            f.write(txt + "\n")

        val_map.append(coco_info[1])  # 保存指标@0.5 mAP，用来画图

        # save weights
        save_files = {
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'lr_scheduler': lr_scheduler.state_dict(),
            'epoch': epoch}
        if args.amp:
            save_files["scaler"] = scaler.state_dict()
        torch.save(save_files, "./save_weights/model-{}.pth".format(epoch))
        import gc

        # gc.collect()
        # torch.cuda.empty_cache()

    # plot loss and lr curve损失和学习率的变化曲线
    if len(train_loss) != 0 and len(learning_rate) != 0:
        from plot_curve import plot_loss_and_lr
        plot_loss_and_lr(train_loss, learning_rate)

    # plot mAP curve mAP曲线
    if len(val_map) != 0:
        from plot_curve import plot_map
        plot_map(val_map)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description=__doc__)

    # 训练设备类型
    parser.add_argument('--device', default='cuda:0', help='device')

    # 训练数据集的根目录(coco2017)
    parser.add_argument('--data-path', default='data/coco2017', help='dataset')

    # COCO数据集人体关键点信息,记录了关键点名称、翻转对应的点位，关键点权重
    parser.add_argument('--keypoints-path', default="./person_keypoints.json", type=str,
                        help='person_keypoints.json path')

    # 原项目提供的验证集person检测信息，想要使用就在default里面加上路径
    # 如果要使用GT（person_detection_result文件）信息，直接将该参数置为None，建议设置成None
    parser.add_argument('--person-det', type=str, default=None)

    # 输入图像的高宽，默认[256, 192]
    parser.add_argument('--fixed-size', default=[256, 192], nargs='+', type=int, help='input size')

    # keypoints点数，Coco中为17
    parser.add_argument('--num-joints', default=8, type=int, help='num_joints')

    # 文件保存地址
    parser.add_argument('--output-dir', default='./save_weights', help='path where to save')

    # 若需要接着上次训练，则指定上次训练保存权重文件地址，再把下面的epoch修改,默认default=''
    parser.add_argument('--resume', default='', type=str, help='resume from checkpoint')

    # 指定接着从哪个epoch数开始训练,上次训练到model-x，下面就填x,默认default='0'
    parser.add_argument('--start-epoch', default='0', type=int, help='start epoch')

    # 训练的总epoch数
    parser.add_argument('--epochs', default=210, type=int, metavar='N',
                        help='number of total epochs to run')

    # 针对torch.optim.lr_scheduler.MultiStepLR的参数 170/200
    parser.add_argument('--lr-steps', default=[140,180], nargs='+', type=int, help='decrease lr every step-size epochs')

    # 针对torch.optim.lr_scheduler.MultiStepLR的参数
    parser.add_argument('--lr-gamma', default=0.1, type=float, help='decrease lr by a factor of lr-gamma')

    # 学习率
    parser.add_argument('--lr', default=0.001, type=float,
                        help='initial learning rate, 0.02 is the default value for training '
                             'on 8 gpus and 2 images_per_gpu')

    # AdamW的weight_decay参数
    parser.add_argument('--wd', '--weight-decay', default=1e-4, type=float,
                        metavar='W', help='weight decay (default: 1e-4)',
                        dest='weight_decay')
    # 训练的batch size
    parser.add_argument('--batch-size', default=16, type=int, metavar='N',
                        help='batch size when training.')

    # 是否使用混合精度训练(需要GPU支持混合精度)，能提升GPU训练速度，减少显存占用
    parser.add_argument("--amp", action="store_true", help="Use torch.cuda.amp for mixed precision training")

    args = parser.parse_args()
    print(args)

    # 检查保存权重文件夹是否存在，不存在则创建
    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)

    main(args)

'''
TP（True positive）: IOU>0.5的检测框个数（注意：每个GT box只能计算一次）
TN（True negative) : IOU <= 0.5，没有被检测到，GT也没有标注的数量。也就是本来是负样例，分类也是负样例。（本文map计算没有用到该指标）。
FP（False positive）: IOU <= 0.5的检测框的个数（或是检测到同一个GT box的多余检测框的数量）
FN（False negative）：没有检测到的GT box的数量

Precision(查准率)：TP/(TP + FP)，代表模型预测的所有目标中，预测正确目标的占比。
Recall(查全率): TP/(TP+FN)，代表所有真实目标中，模型预测正确目标的比例
查准率：宁放过不乱杀
查全率：宁错杀不放过
这里的AP代表mAP
'''
