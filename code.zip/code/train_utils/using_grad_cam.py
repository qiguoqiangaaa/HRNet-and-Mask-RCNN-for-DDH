##生成heatmap
import os
import numpy as np
import json
import cv2
from itertools import groupby
import random
from matplotlib import pyplot as plt
dataset_dir = "./data/coco2017/testv/174byaxo,jpg"

pic_mean = os.path.join('../data/coco2017/')
dataset_save = pic_mean
def normalization(data):
    _range = np.max(data) - np.min(data)
    return (data-np.min(data))/_range*255

def CenterLabelHeatMap(img,kpts,sigma):
    img_height,img_width ,_ = img.shape
    # img = cv2.applyColorMap(img,3)
    X1 = np.linspace(1,img_width,img_width)
    Y1 = np.linspace(1,img_height,img_height)
    heatmap=list()
    result = 0
    for num in range(len(kpts)):
        [X,Y]=np.meshgrid(X1,Y1)
        X = X-kpts[num][0]
        Y = Y-kpts[num][1]
        D2 = X*X+Y*Y
        E2 = 2.0*sigma*sigma
        Exponent = D2/E2
        heatmap_1  =np.exp(-Exponent)
        heatmap_1 = normalization(heatmap_1)
        heatmap_1 = np.array(heatmap_1,np.uint8)
        heatmap.append(heatmap_1)
    for hm in heatmap:
        result+=hm
    heatmap = cv2.applyColorMap(result,cv2.COLORMAP_JET)
    img = img*0.3+heatmap*0.7
    return img,heatmap

def CenterGaussianHeatMap(img,c_x,c_y,variance):
    img_height, img_width, _ = img.shape
    img = cv2.applyColorMap(img, 2)
    gaussian_map = np.zeros((img_height,img_width,3))
    for x_p in range(img_width):
        for y_p in range(img_height):
            dist_sq = (x_p-c_x)*(x_p-c_x)+(y_p-c_y)*(y_p-c_y)
            exponent = dist_sq/2.0/variance/variance
            gaussian_map[y_p,x_p,0] = np.exp(-exponent)
    gaussian_map = normalization(gaussian_map)
    # img[:,:,0]=img[:,:,0]*0.1+gaussian_map[:,:,0]*0.9
    return img
"""
先用groupby将同一个key下的不同人体相同关节点位置取出来
"""
# with open("../data/coco2017/annotations/person_keypoints_testv.json","r") as load_f:
#     load_dict = json.load(load_f)
# ret = list()
# ret_num = list()
# for group_num,group in groupby(load_dict,lambda x: x.get("image_id")):
#     ret.append(list(group))
#     ret_num.append(group_num)
# ret_result = zip(ret_num,ret)
import json
from itertools import groupby

# 读取JSON文件
with open("../data/coco2017/annotations/person_keypoints_testv.json", "r") as load_f:
    load_dict = json.load(load_f)

# 确保所有元素都是字典类型
load_dict = [item for item in load_dict if isinstance(item, dict)]

# 按照'image_id'字段进行分组
load_dict.sort(key=lambda x: x.get("image_id"))
grouped_data = groupby(load_dict, lambda x: x.get("image_id"))

# 将分组结果转化为列表
ret_result = list((key, list(group)) for key, group in grouped_data)


imgIds_old = 0
image = cv2.imread(os.path.join(dataset_dir))

for dict_num in ret_result:
    imgIds = dict_num[0]
    if imgIds==1867 :
        image_path = os.path.join(dataset_dir)
        image = cv2.imread(image_path)
        for kpts_num in range(8):
            joints = list()
            for person_num in range(len(dict_num[1])):
                person_mess = np.array(dict_num[1][person_num]['keypoints']).reshape(-1,3)
                joints.append(person_mess[kpts_num])

            img,heatmap=CenterLabelHeatMap(image,joints,4)
            cv2.imwrite('../data/coco2017/'.format(kpts_num),img)
