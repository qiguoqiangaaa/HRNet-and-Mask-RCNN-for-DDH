from .hrnet import HighResolutionNet
from .resnet import ResNet
from .hrnet_48 import HighResolutionNet_48