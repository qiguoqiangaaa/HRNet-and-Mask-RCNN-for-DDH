import os
import json

import torch
import numpy as np
import cv2
import matplotlib.pyplot as plt
from matplotlib import image

from model import HighResolutionNet
from draw_utils import draw_keypoints
import transforms
from PIL import Image
from confusion import plot_matrix


# normal
def count_images_with_1(source_folder,folder_path,qt,wy,eu,ri):
    jpg_files_with_1_all = []
    jpg_files_with_1 = []
    jpg_files_with_2 = []
    jpg_files_with_3 = []
    jpg_files_with_4 = []
    qt = qt
    wy = wy
    eu = eu
    ri = ri

    try:
        total_jpg_files = 0
        # 遍历数据集统计该类别总量
        for file1 in os.listdir(source_folder):
            if file1.lower().endswith('.jpg'):
                if qt in file1.lower():
                    jpg_files_with_1_all.append(file1)

        # 遍历预测文件夹中的所有图片
        for file2 in os.listdir(folder_path):
            if file2.lower().endswith('.jpg'):
                total_jpg_files += 1

                if qt in file2.lower():             # 1
                    jpg_files_with_1.append(file2)
                if wy in file2.lower():             # 2
                    jpg_files_with_2.append(file2)
                if eu in file2.lower():             # 3
                    jpg_files_with_3.append(file2)
                if ri in file2.lower():             # 4
                    jpg_files_with_4.append(file2)

        num_images_with_1 = len(jpg_files_with_1)
        num_images_with_2 = len(jpg_files_with_2)
        num_images_with_3 = len(jpg_files_with_3)
        num_images_with_4 = len(jpg_files_with_4)
        num_images_with_1_all = len(jpg_files_with_1_all)

        if total_jpg_files > 0:
            percentage_with_a = (num_images_with_1 / num_images_with_1_all) * 100

            # 预测文件夹中的总图片
            # print(f"Total JPG files: {total_jpg_files}")
            print(f"Total normal number: {num_images_with_1_all}")
            print(f"predict normal number: {num_images_with_1}")
            print(f"Percentage of JPG files with the letter {1}: {percentage_with_a:.2f}%")

            return num_images_with_1,num_images_with_2,num_images_with_3,num_images_with_4,num_images_with_1_all
        else:
            print("No JPG files found in the folder.")

    except Exception as e:
        print(f"An error occurred: {str(e)}")


def count_images_with_2(source_folder, folder_path,qt,wy,eu,ri):
    jpg_files_with_2_all = []
    jpg_files_with_1 = []
    jpg_files_with_2 = []
    jpg_files_with_3 = []
    jpg_files_with_4 = []

    qt = qt
    wy = wy
    eu = eu
    ri = ri


    try:
        total_jpg_files = 0
        # 遍历数据集统计该类别总量
        for file1 in os.listdir(source_folder):
            if file1.lower().endswith('.jpg'):
                if qt in file1.lower():     # 所有图片中，仅髋臼发育不良的数量
                    jpg_files_with_2_all.append(file1)

        # 遍历预测文件夹中的所有图片
        for file2 in os.listdir(folder_path):
            if file2.lower().endswith('.jpg'):
                total_jpg_files += 1

                if qt in file2.lower():             # 1
                    jpg_files_with_1.append(file2)
                if wy in file2.lower():             # 2
                    jpg_files_with_2.append(file2)
                if eu in file2.lower():             # 3
                    jpg_files_with_3.append(file2)
                if ri in file2.lower():             # 4
                    jpg_files_with_4.append(file2)

        num_images_with_1 = len(jpg_files_with_1)
        num_images_with_2 = len(jpg_files_with_2)
        num_images_with_3 = len(jpg_files_with_3)
        num_images_with_4 = len(jpg_files_with_4)
        num_images_with_by_all = len(jpg_files_with_2_all)

        if total_jpg_files > 0:
            percentage_with_a = (num_images_with_2 / num_images_with_by_all) * 100

            # 预测文件夹中的总图片
            # print(f"Total JPG files: {total_jpg_files}")
            print(f"Total AD number: {num_images_with_by_all}")
            print(f"predict AD number: {num_images_with_2}")
            print(f"Percentage of JPG files with the letter {2}: {percentage_with_a:.2f}%")

            return num_images_with_1, num_images_with_2, num_images_with_3, num_images_with_4, num_images_with_by_all
        else:
            print("No JPG files found in the folder.")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

# 轻度脱位
def count_images_with_3(source_folder,folder_path,qt,wy,eu,ri):
    jpg_files_with_3_all = []
    jpg_files_with_1 = []
    jpg_files_with_2 = []
    jpg_files_with_3 = []
    jpg_files_with_4 = []

    qt = qt
    wy = wy
    eu = eu
    ri = ri


    try:
        total_jpg_files = 0
        # 遍历数据集统计该类别总量
        for file1 in os.listdir(source_folder):
            if file1.lower().endswith('.jpg'):
                if eu in file1.lower():
                    jpg_files_with_3_all.append(file1)

        # 遍历预测文件夹中的所有图片
        for file2 in os.listdir(folder_path):
            if file2.lower().endswith('.jpg'):
                total_jpg_files += 1

                if qt in file2.lower():             # 1
                    jpg_files_with_1.append(file2)
                if wy in file2.lower():             # 2
                    jpg_files_with_2.append(file2)
                if eu in file2.lower():             # 3
                    jpg_files_with_3.append(file2)
                if ri in file2.lower():             # 4
                    jpg_files_with_4.append(file2)

        num_images_with_1 = len(jpg_files_with_1)
        num_images_with_2 = len(jpg_files_with_2)
        num_images_with_3 = len(jpg_files_with_3)
        num_images_with_4 = len(jpg_files_with_4)
        num_images_with_3_all = len(jpg_files_with_3_all)

        if total_jpg_files > 0:
            percentage_with_a = (num_images_with_3 / num_images_with_3_all) * 100

            # 预测文件夹中的总图片
            # print(f"Total JPG files: {total_jpg_files}")
            print(f"Total JPG in all files with {3}: {num_images_with_3_all}")
            print(f"predict number with {3}: {num_images_with_3}")
            print(f"Percentage of JPG files with the letter {3}: {percentage_with_a:.2f}%")

            return num_images_with_1,num_images_with_2,num_images_with_3,num_images_with_4,num_images_with_3_all
        else:
            print("No JPG files found in the folder.")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

# heavy
def count_images_with_4(source_folder,folder_path,qt,wy,eu,ri):
    jpg_files_with_4_all = []
    jpg_files_with_1 = []
    jpg_files_with_2 = []
    jpg_files_with_3 = []
    jpg_files_with_4 = []

    qt = qt
    wy = wy
    eu = eu
    ri = ri


    try:
        total_jpg_files = 0
        # 遍历数据集统计该类别总量
        for file1 in os.listdir(source_folder):
            if file1.lower().endswith('.jpg'):
                if ri in file1.lower():
                    jpg_files_with_4_all.append(file1)

        # 遍历预测文件夹中的所有图片
        for file2 in os.listdir(folder_path):
            if file2.lower().endswith('.jpg'):
                total_jpg_files += 1

                if qt in file2.lower():             # 1
                    jpg_files_with_1.append(file2)
                if wy in file2.lower():             # 2
                    jpg_files_with_2.append(file2)
                if eu in file2.lower():             # 3
                    jpg_files_with_3.append(file2)
                if ri in file2.lower():             # 4
                    jpg_files_with_4.append(file2)

        num_images_with_1 = len(jpg_files_with_1)
        num_images_with_2 = len(jpg_files_with_2)
        num_images_with_3 = len(jpg_files_with_3)
        num_images_with_4 = len(jpg_files_with_4)
        num_images_with_4_all = len(jpg_files_with_4_all)

        if total_jpg_files > 0:
            percentage_with_a = (num_images_with_4 / num_images_with_4_all) * 100

            # 预测文件夹中的总图片
            # print(f"Total JPG files: {total_jpg_files}")
            print(f"Total heavy number: {num_images_with_4_all}")
            print(f"predict heavy number: {num_images_with_4}")
            print(f"Percentage of JPG files with the letter {4}: {percentage_with_a:.2f}%")

            return num_images_with_1,num_images_with_2,num_images_with_3,num_images_with_4,num_images_with_4_all
        else:
            print("No JPG files found in the folder.")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

