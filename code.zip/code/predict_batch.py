import os
import json

import torch
import numpy as np
import cv2
import matplotlib.pyplot as plt
from matplotlib import image
import pandas as pd
from scipy import stats
from model import HighResolutionNet
from model import HighResolutionNet_48
from draw_utils import draw_keypoints
import transforms
from PIL import Image
from confusion import plot_matrix,plot_matrix_percent
from final_class import count_images_with_1,count_images_with_2,count_images_with_3,count_images_with_4
import re
from pycocotools.coco import COCO
import math



# 只提供单一人体预测，预测的图片必须是单个人体的
def predict_all_person():
    # TODO
    pass

def predict_single_person():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f"using device: {device}")

    # 预测时是否进行图片水平翻转，提高mAP tip：一般来说将原图和翻转后的结果综合，mAP会有略微的提升
    flip_test = True

    resize_hw = (256, 192)


    keypoint_json_path = "person_keypoints.json"
    weights_path = "./save_weights/weight/hrnet.pth"  # 质控


    # read json file
    with open(keypoint_json_path, "r") as f:
        person_info = json.load(f)

    # 源文件夹路径，包含要批量处理的图片文件

    source_folder = './data/coco2017/testchinese'
    source_folder = './mask_rcnn/SEGOUT_original/SEGA_original'


    # 保存的目标文件夹
    target_folder = './data/coco2017/val2017_all'

    normal_r = './data/coco2017/IHDI_2_R'
    mild_r = './data/coco2017/IHDI_3_R'
    heavy_r = './data/coco2017/IHDI_4_R'
    target_folder_kj_R = './data/coco2017/IHDI_1_R'

    normal_l = './data/coco2017/IHDI_2_L'
    mild_l = './data/coco2017/IHDI_3_L'
    heavy_l = './data/coco2017/IHDI_4_L'
    target_folder_kj_L = './data/coco2017/IHDI_1_L'

    import shutil
    def delete_folder(folder_path):
        try:
            # 使用shutil.rmtree删除文件夹及其内容
            shutil.rmtree(folder_path)
            print(f"Successfully deleted the folder: {folder_path}")
        except Exception as e:
            print(f"An error occurred: {str(e)}")
    delete_folder(normal_r)
    delete_folder(mild_r)
    delete_folder(heavy_r)

    delete_folder(target_folder_kj_R)
    delete_folder(target_folder_kj_L)
    delete_folder(normal_l)
    delete_folder(mild_l)
    delete_folder(heavy_l)


    # 创建目标文件夹，如果不存在
    os.makedirs(normal_r, exist_ok=True)
    os.makedirs(mild_r, exist_ok=True)
    os.makedirs(heavy_r, exist_ok=True)

    os.makedirs(normal_l, exist_ok=True)
    os.makedirs(mild_l, exist_ok=True)
    os.makedirs(heavy_l, exist_ok=True)

    os.makedirs(target_folder_kj_R, exist_ok=True)
    os.makedirs(target_folder_kj_L, exist_ok=True)

    kj_R_number = 0
    kj_L_number = 0

    # 求角度均值和方差的列表
    theta_degrees_R_list = []
    theta_degrees_L_list = []
    theta_degrees_R_CE_list = []
    theta_degrees_L_CE_list = []
    # 获取源文件夹中的所有图片名
    file_names = os.listdir(source_folder)

    results_degree = []
    # 假设预测结果和真实标签存储在以下变量中
    all_predicted_keypoints = []  # 存储所有图像的预测关键点坐标
    all_true_keypoints = []  # 存储所有图像的真实关键点坐标

    # 初始化空列表，用于存储所有图像的预测精确率、召回率、mAP 和 F1 值
    all_precisions = []
    all_recalls = []

    all_F1_scores = []
    # 将结果添加到相应的列表中
    all_precisions_right_hip = []
    all_recalls_right_hip = []
    all_f1_scores_right_hip = []

    all_precisions_left_hip = []
    all_recalls_left_hip = []
    all_f1_scores_left_hip = []



    for file_name in file_names:
        # 构建源文件的完整路径
        source_file_path = os.path.join(source_folder, file_name)
        print(source_file_path)
        image_path = source_file_path  # 替换为你图片的路径
        img = Image.open(image_path)
        # 获取图像的实际尺寸
        width, height = img.size
        print(f"Image width: {width}, Image height: {height}")

        assert os.path.exists(source_file_path), f"file: {source_file_path} does not exist."
        assert os.path.exists(weights_path), f"file: {weights_path} does not exist."
        assert os.path.exists(keypoint_json_path), f"file: {keypoint_json_path} does not exist."

        # 数据增强
        data_transform = transforms.Compose([
            transforms.AffineTransform(scale=(1.25, 1.25), fixed_size=resize_hw),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        # 读取图片
        img = cv2.imread(source_file_path)
        # 这里opencv读取的图片是BGR，这里转化为RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        # 额外传入一个字典参数target，记录了原始图片的高宽信息，因为预测的图片需要缩放，预测完后还要还原为原来的大小
        img_tensor, target = data_transform(img, {"box": [0, 0, img.shape[1] - 1, img.shape[0] - 1]})
        # 增加batch维度
        img_tensor = torch.unsqueeze(img_tensor, dim=0)

        # create model
        # HRNet-W32: base_channel=32
        # HRNet-W48: base_channel=48
        model = HighResolutionNet(base_channel=32)
        weights = torch.load(weights_path, map_location=device)
        weights = weights if "model" not in weights else weights["model"]
        model.load_state_dict(weights)
        model.to(device)
        model.eval()

        with torch.inference_mode():
            # 输入模型进行预测
            outputs = model(img_tensor.to(device))
            # 如果进行翻转
            if flip_test:
                flip_tensor = transforms.flip_images(img_tensor)    # 翻转
                # 输入到网络进行预测，再翻转回来
                flip_outputs = torch.squeeze(
                    transforms.flip_back(model(flip_tensor.to(device)), person_info["flip_pairs"]),
                )
                # feature is not aligned, shift flipped heatmap for higher accuracy
                # https://github.com/leoxiaobin/deep-high-resolution-net.pytorch/issues/22
                flip_outputs[..., 1:] = flip_outputs.clone()[..., 0: -1]
                # 将两个结果取平均,获得最终的预测结果
                outputs = (outputs + flip_outputs) * 0.5

            # get_final_preds 将预测结果还原回原尺度
            # 并做了关键点最终坐标的计算，这里并不是直接选择最大的响应点，而是最大响应点向第二大响应点偏移后的坐标
            # 函数的返回值是一个元组，包含两个数组：keypoints和scores。
            # keypoints是关键点的坐标信息，它的形状是(batch_size, num_joints, 2)，其中batch_size表示批量大小，num_joints表示关键点的数量
            # 2表示坐标的维度（x和y）
            # scores是关键点的得分，它的形状是(batch_size, num_joints, 1)，表示每个关键点的置信度得分。
            # np.squeeze函数将关键点和得分数组的维度1去除，得到的是形状为(num_joints, 2)和(num_joints, 1)的数组，表示关键点的坐标和得分。
            keypoints, scores = transforms.get_final_preds(outputs, [target["reverse_trans"]], True)
            keypoints = np.squeeze(keypoints)   # 关键点信息
            scores = np.squeeze(scores)         # 关键点的分数



            # 绘制关键点信息
            plot_img = draw_keypoints(img, keypoints, scores, thresh=0, r=10)

            # 绘制水平线(连接1,5两点并延长)**********************************************************************************
            # Hilgenreiner
            slope = (keypoints[5][1] - keypoints[1][1]) / (keypoints[5][0] - keypoints[1][0])
            extension_length = 200  # 定义延长的长度，可以根据需要进行调整
            new_point1 = (keypoints[1][0] - extension_length, keypoints[1][1] - extension_length * slope)
            new_point2 = (keypoints[5][0] + extension_length, keypoints[5][1] + extension_length * slope)
            plt.plot([new_point1[0], new_point2[0]], [new_point1[1], new_point2[1]],color='deepskyblue')  # 先写x的取值范围，再写y的取值范围
            new_point1_AI_degreer = new_point1
            new_point1_AI_degreel = new_point2

            # 绘制右髋垂线*************************************************************************************************
            slope = (keypoints[5][1] - keypoints[1][1]) / (keypoints[5][0] - keypoints[1][0])  # 计算原直线的斜率
            print(slope)
            if abs(slope) < 0.01:
                start_point = (keypoints[0][0], keypoints[0][1])  # 选择一个点作为起始点
                delta_x = 100  # 移动一定距离
                line_length = 200
                end_point = (start_point[0], start_point[1] + line_length)
                end_point_r1 = end_point
                # 绘制
                plt.plot([start_point[0], end_point[0]], [start_point[1], end_point[1]], label='Perpendicular Line',
                         linestyle='-', color='deepskyblue')
            else:
                perpendicular_slope = -1 / slope  # 计算垂线的斜率（原直线的斜率的负倒数）
                start_point = (keypoints[0][0], keypoints[0][1])  # 选择一个点作为起始点
                delta_x = 100  # 移动一定距离
                delta_y = perpendicular_slope * delta_x
                line_length = 200
                end_point = (start_point[0] + line_length / (1 + perpendicular_slope ** 2) ** 0.5,
                             start_point[1] + (perpendicular_slope * line_length) / (
                                         1 + perpendicular_slope ** 2) ** 0.5)
                end_point_r1 = end_point
                # 绘制
                plt.plot([start_point[0], end_point[0]], [start_point[1], end_point[1]], label='Perpendicular Line',
                         linestyle='-', color='deepskyblue')
            # 绘制第二部分
            if abs(slope) < 0.01:
                start_point = (keypoints[0][0], keypoints[0][1])  # 选择一个点作为起始点
                delta_x = 100  # 移动一定距离
                line_length = -200
                end_point = (start_point[0], start_point[1] + line_length)
                end_point_r2 = end_point
                # 绘制
                plt.plot([start_point[0], end_point[0]], [start_point[1], end_point[1]], label='Perpendicular Line',
                         linestyle='-', color='deepskyblue')
            else:
                perpendicular_slope = -1 / slope  # 计算垂线的斜率（原直线的斜率的负倒数）
                start_point = (keypoints[0][0], keypoints[0][1])  # 选择一个点作为起始点
                delta_x = 100  # 移动一定距离
                delta_y = perpendicular_slope * delta_x
                line_length = -200
                end_point = (start_point[0] + line_length / (1 + perpendicular_slope ** 2) ** 0.5,
                             start_point[1] + (perpendicular_slope * line_length) / (
                                         1 + perpendicular_slope ** 2) ** 0.5)
                end_point_r2 = end_point
                # 绘制
                plt.plot([start_point[0], end_point[0]], [start_point[1], end_point[1]], label='Perpendicular Line',
                         linestyle='-', color='deepskyblue')
            # 绘制左髋垂线**************************************************************************************************
            # Perkin
            slope = (keypoints[5][1] - keypoints[1][1]) / (keypoints[5][0] - keypoints[1][0])  # 计算原直线的斜率
            print(slope)
            if abs(slope) < 0.01:
                start_point = (keypoints[4][0], keypoints[4][1])  # 选择一个点作为起始点
                delta_x = 100  # 移动一定距离
                line_length = 200
                end_point = (start_point[0], start_point[1] + line_length)
                end_point_l1 = end_point
                # 绘制
                plt.plot([start_point[0], end_point[0]], [start_point[1], end_point[1]], label='Perpendicular Line',
                         linestyle='-', color='deepskyblue')
            else:
                perpendicular_slope = -1 / slope  # 计算垂线的斜率（原直线的斜率的负倒数）
                start_point = (keypoints[4][0], keypoints[4][1])  # 选择一个点作为起始点
                delta_x = 100  # 移动一定距离
                delta_y = perpendicular_slope * delta_x
                line_length = 200
                end_point = (start_point[0] + line_length / (1 + perpendicular_slope ** 2) ** 0.5,
                             start_point[1] + (perpendicular_slope * line_length) / (
                                         1 + perpendicular_slope ** 2) ** 0.5)
                end_point_l1 = end_point
                # 绘制
                plt.plot([start_point[0], end_point[0]], [start_point[1], end_point[1]], label='Perpendicular Line',
                         linestyle='-', color='deepskyblue')
            # 绘制第二部分
            if abs(slope) < 0.01:
                start_point = (keypoints[4][0], keypoints[4][1])  # 选择一个点作为起始点
                delta_x = 100  # 移动一定距离
                line_length = -200
                end_point = (start_point[0], start_point[1] + line_length)
                end_point_l2 = end_point
                # 绘制
                plt.plot([start_point[0], end_point[0]], [start_point[1], end_point[1]], label='Perpendicular Line',
                         linestyle='-', color='deepskyblue')
            else:
                perpendicular_slope = -1 / slope  # 计算垂线的斜率（原直线的斜率的负倒数）
                start_point = (keypoints[4][0], keypoints[4][1])  # 选择一个点作为起始点
                delta_x = 100  # 移动一定距离
                delta_y = perpendicular_slope * delta_x
                line_length = -200
                end_point = (start_point[0] + line_length / (1 + perpendicular_slope ** 2) ** 0.5,
                             start_point[1] + (perpendicular_slope * line_length) / (
                                         1 + perpendicular_slope ** 2) ** 0.5)
                end_point_l2 = end_point
                # 绘制
                plt.plot([start_point[0], end_point[0]], [start_point[1], end_point[1]], label='Perpendicular Line',
                         linestyle='-', color='deepskyblue')

            # ********************************************************************************************************
            # 右髋关节1-0延长线
            slope = (keypoints[0][1] - keypoints[1][1]) / (keypoints[0][0] - keypoints[1][0])
            extension_length = 100  # 定义延长的长度，可以根据需要进行调整
            new_point1 = (keypoints[0][0] - extension_length, keypoints[0][1] - extension_length * slope)
            plt.plot([new_point1[0], keypoints[1][0]], [new_point1[1], keypoints[1][1]],color='coral')
            # 左髋关节5-4延长线
            slope = (keypoints[4][1] - keypoints[5][1]) / (keypoints[4][0] - keypoints[5][0])
            extension_length = 100  # 定义延长的长度，可以根据需要进行调整
            new_point2 = (keypoints[4][0] + extension_length, keypoints[4][1] + extension_length * slope)
            plt.plot([new_point2[0], keypoints[5][0]], [new_point2[1], keypoints[5][1]],color='coral')


            # ********************************************************************************************************


            # 右髋臼角0-1-1延长(AI)
            # 定义三个点的坐标
            point1 = (keypoints[1][0], keypoints[1][1])     # 內沿
            point2 = (keypoints[0][0], keypoints[0][1])     # 外沿
            point3 = new_point1_AI_degreer                             # 內沿延长点

            vector1 = np.array([point2[0] - point1[0], point2[1] - point1[1]]) # 计算向量1，它是 point1 指向 point2 的向量
            vector2 = np.array([point1[0] - point3[0], point1[1] - point3[1]]) # 计算向量2，它是 point3 指向 point1 的向量
            dot_product = np.dot(vector1, vector2)  # 计算向量1 和向量2 的点积
            norm_vector1 = np.linalg.norm(vector1)# 计算向量1 和向量2 的模
            norm_vector2 = np.linalg.norm(vector2)
            cosine_theta = dot_product / (norm_vector1 * norm_vector2)# 计算夹角的余弦值
            theta_radians = np.arccos(cosine_theta)# 计算夹角的弧度值
            theta_degrees_R = np.degrees(theta_radians)# 将弧度值转换为角度值
            if theta_degrees_R >= 90:
                theta_degrees_R = 180 - theta_degrees_R

            label_x = 200  # 调整文本标签的位置
            label_y = 50
            plt.text(label_x, label_y, f'AI R: {theta_degrees_R:.2f} degrees', fontsize=10, color='blue', fontweight='bold')

            # 左髋臼角4-5-5延长(AI)
            # 定义三个点的坐标
            point1 = (keypoints[5][0], keypoints[5][1])  # 內沿
            point2 = (keypoints[4][0], keypoints[4][1])  # 外沿
            point3 = new_point1_AI_degreel  # 內沿延长点

            vector1 = np.array([point2[0] - point1[0], point2[1] - point1[1]])  # 计算向量1，它是 point1 指向 point2 的向量
            vector2 = np.array([point3[0] - point1[0], point3[1] - point1[1]])  # 计算向量2，它是 point3 指向 point1 的向量
            dot_product = np.dot(vector1, vector2)  # 计算向量1 和向量2 的点积
            norm_vector1 = np.linalg.norm(vector1)  # 计算向量1 和向量2 的模
            norm_vector2 = np.linalg.norm(vector2)
            cosine_theta = dot_product / (norm_vector1 * norm_vector2)  # 计算夹角的余弦值
            theta_radians = np.arccos(cosine_theta)  # 计算夹角的弧度值
            theta_degrees_L = np.degrees(theta_radians)  # 将弧度值转换为角度值
            if theta_degrees_L >= 90:
                theta_degrees_L = 180 - theta_degrees_L

            label_x = 650  # 调整文本标签的位置
            label_y = 50
            plt.text(label_x, label_y, f'AI L: {theta_degrees_L:.2f} degrees', fontsize=10, color='blue', fontweight='bold')
            # ********************************************************************************************************


            # CE角R
            slope = (keypoints[5][1] - keypoints[1][1]) / (keypoints[5][0] - keypoints[1][0])  # 计算原直线的斜率
            perpendicular_slope = -1 / slope  # 计算垂线的斜率（原直线的斜率的负倒数）
            point1 = (keypoints[2][0], keypoints[2][1])  # 右中心点
            point2 = (keypoints[0][0], keypoints[0][1])  # 外沿
            point3 = (keypoints[2][0] - 100 , keypoints[2][1] - 100 * perpendicular_slope)  # 內沿延长点
            if abs(slope) < 0.01:
                point3 = (keypoints[2][0], keypoints[2][1] - 100)

            vector1 = np.array([point2[0] - point1[0], point2[1] - point1[1]])  # 计算向量1，它是 point1 指向 point2 的向量
            vector2 = np.array([point3[0] - point1[0], point3[1] - point1[1]])  # 计算向量2，它是 point3 指向 point1 的向量
            dot_product = np.dot(vector1, vector2)  # 计算向量1 和向量2 的点积
            norm_vector1 = np.linalg.norm(vector1)  # 计算向量1 和向量2 的模
            norm_vector2 = np.linalg.norm(vector2)
            cosine_theta = dot_product / (norm_vector1 * norm_vector2)  # 计算夹角的余弦值
            theta_radians = np.arccos(cosine_theta)  # 计算夹角的弧度值
            theta_degrees_R_CE = np.degrees(theta_radians)  # 将弧度值转换为角度值
            if theta_degrees_R_CE >= 90:
                theta_degrees_R_CE = 180 - theta_degrees_R_CE
            if keypoints[2][0] <= keypoints[0][0]:
                theta_degrees_R_CE = -1 * theta_degrees_R_CE
            # label_x = 200  # 调整文本标签的位置
            # label_y = 100
            # plt.text(label_x, label_y, f'CE R: {theta_degrees_R_CE:.2f} degrees', fontsize=10, color='blue', fontweight='bold')

            # 记录所有求得的右髋ce角度
            if theta_degrees_R_CE < 35 and theta_degrees_R_CE > -8:
                theta_degrees_R_CE_list.append(theta_degrees_R_CE)

            # CE角L
            point1 = (keypoints[6][0], keypoints[6][1])  # 內沿
            point2 = (keypoints[4][0], keypoints[4][1])  # 外沿
            point3 = (keypoints[6][0]+ 100, keypoints[6][1] + 100 * perpendicular_slope)  # 內沿延长点
            if abs(slope) < 0.01:
                point3 = (keypoints[6][0], keypoints[6][1] - 100)

            vector1 = np.array([point2[0] - point1[0], point2[1] - point1[1]])  # 计算向量1，它是 point1 指向 point2 的向量
            vector2 = np.array([point3[0] - point1[0], point3[1] - point1[1]])  # 计算向量2，它是 point3 指向 point1 的向量
            dot_product = np.dot(vector1, vector2)  # 计算向量1 和向量2 的点积
            norm_vector1 = np.linalg.norm(vector1)  # 计算向量1 和向量2 的模
            norm_vector2 = np.linalg.norm(vector2)
            cosine_theta = dot_product / (norm_vector1 * norm_vector2)  # 计算夹角的余弦值
            theta_radians = np.arccos(cosine_theta)  # 计算夹角的弧度值
            theta_degrees_L_CE = np.degrees(theta_radians)  # 将弧度值转换为角度值
            if theta_degrees_L_CE >= 90:
                theta_degrees_L_CE = 180 - theta_degrees_L_CE
            if keypoints[6][0] >= keypoints[4][0]:
                theta_degrees_L_CE = -1 * theta_degrees_L_CE
            # label_x = 650  # 调整文本标签的位置
            # label_y = 100
            # plt.text(label_x, label_y, f'CE L: {theta_degrees_L_CE:.2f} degrees', fontsize=10, color='blue', fontweight='bold')

            # 记录所有求得的左髋ce角度
            if theta_degrees_L_CE < 30 and theta_degrees_L_CE > -6:
                theta_degrees_L_CE_list.append(theta_degrees_L_CE)


            # ********************************************************************************************************
            # 求H,P两线交点（R）
            slope = (keypoints[5][1] - keypoints[1][1]) / (keypoints[5][0] - keypoints[1][0])
            extension_length = 300  # 定义延长的长度，可以根据需要进行调整
            new_point1 = (keypoints[1][0] - extension_length, keypoints[1][1] - extension_length * slope)
            new_point2 = (keypoints[5][0] + extension_length, keypoints[5][1] + extension_length * slope)

            def find_intersection(line1, line2):
                x1, y1, x2, y2 = line1
                x3, y3, x4, y4 = line2

                # 线段1的斜率
                m1 = (y2 - y1) / (x2 - x1) if x2 - x1 != 0 else float('inf')
                # 线段2的斜率
                m2 = (y4 - y3) / (x4 - x3) if x4 - x3 != 0 else float('inf')

                # 如果两条线段平行（斜率相等），则没有交点
                if m1 == m2:
                    return None

                # 计算交点的 x 和 y 坐标
                if m1 == float('inf'):
                    x = x1
                    y = m2 * (x - x3) + y3
                elif m2 == float('inf'):
                    x = x3
                    y = m1 * (x - x1) + y1
                else:
                    x = (y3 - y1 + m1 * x1 - m2 * x3) / (m1 - m2)
                    y = m1 * (x - x1) + y1

                return (x, y)

            # 右侧髋关节HP线交点
            line1 = (new_point1[0], new_point1[1], new_point2[0], new_point2[1])
            line2 = (end_point_r1[0], end_point_r1[1], end_point_r2[0], end_point_r2[1])
            # 计算交点
            intersection_R = find_intersection(line1, line2)
            plt.plot([intersection_R[0], keypoints[3][0]], [intersection_R[1], keypoints[3][1]], color='yellow')

            # 左侧髋关节HP线交点
            line1 = (new_point1[0], new_point1[1], new_point2[0], new_point2[1])
            line2 = (end_point_l1[0], end_point_l1[1], end_point_l2[0], end_point_l2[1])
            # 计算交点
            intersection_L = find_intersection(line1, line2)
            plt.plot([intersection_L[0], keypoints[7][0]], [intersection_L[1], keypoints[7][1]], color='yellow')

            # IHDI角度****************************************************************************************************
            # 右髋

            point1 = (intersection_R[0], intersection_R[1])  # HP交点
            point2 = (keypoints[1][0], keypoints[1][1])  # 点1
            point3 = (keypoints[3][0], keypoints[3][1])  #点3

            vector1 = np.array([point2[0] - point1[0], point2[1] - point1[1]])  # 计算向量1，它是 point1 指向 point2 的向量
            vector2 = np.array([point3[0] - point1[0], point3[1] - point1[1]])  # 计算向量2，它是 point3 指向 point1 的向量
            dot_product = np.dot(vector1, vector2)  # 计算向量1 和向量2 的点积
            norm_vector1 = np.linalg.norm(vector1)  # 计算向量1 和向量2 的模
            norm_vector2 = np.linalg.norm(vector2)
            cosine_theta = dot_product / (norm_vector1 * norm_vector2)  # 计算夹角的余弦值
            theta_radians = np.arccos(cosine_theta)  # 计算夹角的弧度值
            IHDI_R = np.degrees(theta_radians)  # 将弧度值转换为角度值
            if keypoints[3][1] <= new_point1_AI_degreer[1]:
                IHDI_R = 180 - IHDI_R +180
            label_x = 200  # 调整文本标签的位置
            label_y = 100
            if IHDI_R >= 180:
                IHDI_R2 = IHDI_R - 180
                plt.text(label_x, label_y, f'IHDI : {IHDI_R2:.2f} degrees', fontsize=10, color='blue', fontweight='bold')
            if IHDI_R < 180:
                plt.text(label_x, label_y, f'IHDI : {IHDI_R:.2f} degrees', fontsize=10, color='blue', fontweight='bold')


            # IHDI角度****************************************************************************************************
            # 左髋
            point1 = (intersection_L[0], intersection_L[1])  # HP交点
            point2 = (keypoints[5][0], keypoints[5][1])  # 点1
            point3 = (keypoints[7][0], keypoints[7][1])  # 点3

            vector1 = np.array([point2[0] - point1[0], point2[1] - point1[1]])  # 计算向量1，它是 point1 指向 point2 的向量
            vector2 = np.array([point3[0] - point1[0], point3[1] - point1[1]])  # 计算向量2，它是 point3 指向 point1 的向量
            dot_product = np.dot(vector1, vector2)  # 计算向量1 和向量2 的点积
            norm_vector1 = np.linalg.norm(vector1)  # 计算向量1 和向量2 的模
            norm_vector2 = np.linalg.norm(vector2)
            cosine_theta = dot_product / (norm_vector1 * norm_vector2)  # 计算夹角的余弦值
            theta_radians = np.arccos(cosine_theta)  # 计算夹角的弧度值
            IHDI_L = np.degrees(theta_radians)  # 将弧度值转换为角度值
            if keypoints[7][1] <= new_point1_AI_degreel[1]:
                IHDI_L = 180 - IHDI_L +180
            label_x = 650  # 调整文本标签的位置
            label_y = 100
            if IHDI_L >= 180:
                IHDI_L2 = IHDI_L - 180
                plt.text(label_x, label_y, f'IHDI : {IHDI_L2:.2f} degrees', fontsize=10, color='blue', fontweight='bold')
            if IHDI_L < 180:
                plt.text(label_x, label_y, f'IHDI : {IHDI_L:.2f} degrees', fontsize=10, color='blue', fontweight='bold')


            plt.xlabel('X')
            plt.ylabel('Y')
            plt.imshow(plot_img)
            # 保存带线的图像
            # 构建目标文件的完整路径


            target_folder_R = None
            # IHDI 1
            if 0 < IHDI_R < 90:
                target_folder_kj_R = target_folder_kj_R
                kj_R_number += 1
                # kj_R = os.path.join(target_folder_kj_R, file_name)
                plt.text(200, 150, f'IHDI Ⅰ', fontsize=10, color='blue', fontweight='bold')
                target_folder_R = target_folder_kj_R

            # IHDI 2
            if 90 <= IHDI_R < 135:
                target_folder_R = normal_r
                plt.text(200, 150, f'IHDI Ⅱ', fontsize=10, color='blue', fontweight='bold')
            # IHDI 3
            if 135 <= IHDI_R < 180:
                target_folder_R = mild_r
                plt.text(200, 150, f'IHDI Ⅲ', fontsize=10, color='blue', fontweight='bold')
            # IHDI 4
            if IHDI_R >= 180:
                target_folder_R = heavy_r
                plt.text(200, 150, f'IHDI Ⅳ', fontsize=10, color='blue', fontweight='bold')

            # 记录所有求得的右髋AI角度

            theta_degrees_R_list.append(theta_degrees_R)

            theta_degrees_L_list.append(theta_degrees_L)

            target_folder_L = None

            if 0 < IHDI_L < 90:
                target_folder_kj_L = target_folder_kj_L
                kj_L_number += 1
                # kj_L = os.path.join(target_folder_kj_L, file_name)
                plt.text(650, 150, f'IHDI Ⅰ', fontsize=10, color='blue', fontweight='bold')
                target_folder_L =  target_folder_kj_L
                # plt.savefig(kj_L)

            # normal
            if 90<= IHDI_L < 135:
                target_folder_L = normal_l
                plt.text(650, 150, f'IHDI Ⅱ', fontsize=10, color='blue', fontweight='bold')
            # mid
            if 135<= IHDI_L < 180:
                target_folder_L = mild_l
                plt.text(650, 150, f'IHDI Ⅲ', fontsize=10, color='blue', fontweight='bold')
            # heavy
            if IHDI_L >= 180:
                target_folder_L = heavy_l
                plt.text(650, 150, f'IHDI Ⅳ', fontsize=10, color='blue', fontweight='bold')



            #保存图片
            if target_folder_R != None:
                target_file_path_R = os.path.join(target_folder_R, file_name)
                plt.savefig(target_file_path_R)
            if target_folder_L != None:
                target_file_path_L = os.path.join(target_folder_L, file_name)
                plt.savefig(target_file_path_L)

            plt.cla()





            # **********************************************************************保存角度
            # 定义一个正则表达式来匹配数字部分
            pattern = re.compile(r'\d+')
            # 使用正则表达式匹配字符串中的数字部分
            # imgnum = pattern.search(file_name)
            imgnum = file_name
            print(imgnum)

            # 将图片名和对应的两个结果存储为字典
            result_dict = {
                'image_name': imgnum,
                'AI_R': theta_degrees_R,
                'AI_L': theta_degrees_L,
            }

            # 将结果添加到列表中
            results_degree.append(result_dict)


            #****************************************************************************************************
            # ****************************************************************************************************
            img_path = image_path
            image_filename = file_name
            keypoints_pairs = []
            truelabel_path = "./data/coco2017/annotations/test190.json"
            # 读取JSON文件
            with open(truelabel_path, 'r') as json_file:
                annotations_all = json.load(json_file)
            coco = COCO(truelabel_path)
            img_ids = list(sorted(coco.imgs.keys()))
            det_json_path = None
            if det_json_path is not None:
                det = coco.loadRes(det_json_path)
            else:
                det = coco
            valid_person_list = []
            obj_idx = 0
            for img_id in img_ids:
                img_info = coco.loadImgs(img_id)[0]
                ann_ids = det.getAnnIds(imgIds=img_id)
                anns = det.loadAnns(ann_ids)
                for ann in anns:
                    # 只保存原coco数据集的person类标注
                    # if ann["category_id"] != 1:
                    #     print(f'warning: find not support id: {ann["category_id"]}, only support id: 1 (person)')
                    #     continue

                    # skip objs without keypoints annotation
                    if "keypoints" not in ann:
                        continue
                    if max(ann["keypoints"]) == 0:
                        continue

                    xmin, ymin, w, h = ann['bbox']
                    # Use only valid bounding boxes
                    if w > 0 and h > 0:
                        info = {
                            "box": [xmin, ymin, w, h],
                            "image_path": img_path,
                            "image_id": img_id,
                            "image_width": img_info['width'],
                            "image_height": img_info['height'],
                            "obj_origin_hw": [h, w],
                            "obj_index": obj_idx,
                            "score": ann["score"] if "score" in ann else 1.,
                            # "file_name": img_info['file_name'],
                        }
                        image_id_pre = None
                        # 查找特定图像文件名对应的图像ID
                        image_id = None
                        for image in annotations_all['images']:
                            if image['file_name'] == image_filename:
                                image_id = image['id']
                                break

                        # 根据找到的图像ID获取对应的关键点信息
                        if image_id is not None:
                            keypoints_info = next(
                                (item for item in annotations_all['annotations'] if item['image_id'] == image_id),
                                None)
                            if keypoints_info:
                                true_keypoints = keypoints_info['keypoints']
                                # keypoints_true = np.squeeze(keypoints_true)  # 关键点信息

                                for i in range(0, len(true_keypoints), 3):
                                    x = true_keypoints[i]
                                    y = true_keypoints[i + 1]
                                    keypoints_pairs.append([x, y])

                                    # 当存储元素长度等于8，则进行保存，并情清空列表
                                    if len(keypoints_pairs) == 8:
                                        true_keypoints = [keypoints_pairs[0],
                                                          keypoints_pairs[1],
                                                          keypoints_pairs[2],
                                                          keypoints_pairs[3],
                                                          keypoints_pairs[4],
                                                          keypoints_pairs[5],
                                                          keypoints_pairs[6],
                                                          keypoints_pairs[7]]  # 假设这里是真实标签的关键点坐标
                                        #all_true_keypoints.append(true_keypoints)  # 存储所有图像的真实关键点坐标################
                                        keypoints_pairs = []


                                # print(f"Image ID: {image_id}, Keypoints: {true_keypoints}")

                            else:
                                print("No keypoints found for the given image.")
                        else:
                            print("Given image file name not found in the dataset.")

            # print("Keypoints:", keypoints_pairs)
            # keypoints_true[0][0]
            # 获取真实标签的关键点坐标信息（假设已有）


            # true_keypoints = [keypoints_pairs[0],
            #                   keypoints_pairs[1],
            #                   keypoints_pairs[2],
            #                   keypoints_pairs[3],
            #                   keypoints_pairs[4],
            #                   keypoints_pairs[5],
            #                   keypoints_pairs[6],
            #                   keypoints_pairs[7]]  # 假设这里是真实标签的关键点坐标

            # print(true_keypoints)
            predicted_keypoints = keypoints


            def compute_precision_recall(true_keypoints, predicted_keypoints, threshold=20):
                true_positives = 0
                false_positives = 0
                false_negatives = 0

                # for i in range(len(true_keypoints)):  # 遍历每个真实关键点
                for idx, true_keypoint in enumerate(true_keypoints):

                    true_x, true_y = true_keypoint[0],true_keypoint[1]  # 提取真实关键点坐标
                    predicted_x, predicted_y = predicted_keypoints[idx] # 提取预测关键点坐标
                    distance = np.sqrt((true_x - predicted_x) ** 2 + (true_y - predicted_y) ** 2)
                    if distance <= threshold:
                        true_positives += 1
                    else:
                        false_negatives += 1

                for i in range(len(predicted_keypoints)):  # 遍历每个预测关键点
                    predicted_x, predicted_y = predicted_keypoints[i]  # 提取预测关键点坐标
                    found_match = False
                    for j in range(len(true_keypoints)):  # 在真实关键点中查找匹配
                        true_x, true_y = true_keypoints[j][0],true_keypoints[j][1]  # 提取真实关键点坐标
                        distance = np.sqrt((true_x - predicted_x) ** 2 + (true_y - predicted_y) ** 2)
                        if distance <= threshold:
                            found_match = True
                            break
                    if not found_match:
                        false_positives += 1

                precision = true_positives / (true_positives + false_positives)
                recall = true_positives / (true_positives + false_negatives)

                return precision, recall

            def compute_mAP(true_keypoints, predicted_keypoints, threshold=15):
                precisions = []
                recalls = []
                for i in range(len(true_keypoints)):
                    precision, recall = compute_precision_recall(true_keypoints, predicted_keypoints, threshold)
                    precisions.append(precision)
                    recalls.append(recall)
                return np.mean(precisions), np.mean(recalls)

            def compute_F1(precision, recall):
                return 2 * precision * recall / (precision + recall + 0.000000001)

            # 计算左髋、右髋函数
            def compute_precision_recall_f1(true_keypoints, predicted_keypoints):
                # 提取右髋和左髋的关键点坐标
                true_right_hip = true_keypoints[:2]
                predicted_right_hip = predicted_keypoints[:2]
                true_left_hip = true_keypoints[2:4]
                predicted_left_hip = predicted_keypoints[2:4]

                # 计算右髋的精确率和召回率
                precision_right_hip, recall_right_hip = compute_precision_recall(true_right_hip,
                                                                                 predicted_right_hip)
                # 计算右髋的F1值
                f1_right_hip = compute_F1(precision_right_hip, recall_right_hip)

                # 计算左髋的精确率和召回率
                precision_left_hip, recall_left_hip = compute_precision_recall(true_left_hip, predicted_left_hip)
                # 计算左髋的F1值
                f1_left_hip = compute_F1(precision_left_hip, recall_left_hip)

                return precision_right_hip, recall_right_hip, f1_right_hip, precision_left_hip, recall_left_hip, f1_left_hip

            # # 遍历所有图像
            # for i in range(len(all_predicted_keypoints)):
            #     predicted_keypoints = all_predicted_keypoints[i]
            #     true_keypoints = all_true_keypoints[i]

            # 计算整体的精确率和召回率
            precision, recall = compute_precision_recall(true_keypoints, predicted_keypoints)
            all_precisions.append(precision)
            all_recalls.append(recall)
            # 计算F1值
            F1 = compute_F1(precision, recall)
            all_F1_scores.append(F1)

            # 计算单侧髋精确率、召回率和F1值
            precision_right_hip, recall_right_hip, f1_right_hip, precision_left_hip, recall_left_hip, f1_left_hip = compute_precision_recall_f1(true_keypoints, predicted_keypoints)
            # 将结果添加到相应的列表中
            # 右
            all_precisions_right_hip.append(precision_right_hip)
            all_recalls_right_hip.append(recall_right_hip)
            all_f1_scores_right_hip.append(f1_right_hip)
            # 左
            all_precisions_left_hip.append(precision_left_hip)
            all_recalls_left_hip.append(recall_left_hip)
            all_f1_scores_left_hip.append(f1_left_hip)



    # 计算所有图像的平均值
    average_precision = np.mean(all_precisions)
    average_recall = np.mean(all_recalls)
    # average_mAP_05_precision = np.mean(all_mAP_05_precisions)
    # average_mAP_05_recall = np.mean(all_mAP_05_recalls)
    # average_mAP_05_095_precision = np.mean(all_mAP_05_095_precisions)
    # average_mAP_05_095_recall = np.mean(all_mAP_05_095_recalls)
    average_F1_score = np.mean(all_F1_scores)

    # 打印结果
    print("Average Precision:", average_precision)
    print("Average Recall:", average_recall)
    # print("Average mAP@0.5 Precision:", average_mAP_05_precision)
    # print("Average mAP@0.5 Recall:", average_mAP_05_recall)
    # print("Average mAP@0.5:0.95 Precision:", average_mAP_05_095_precision)
    # print("Average mAP@0.5:0.95 Recall:", average_mAP_05_095_recall)
    print("Average F1 Score:", average_F1_score)

    # 计算单侧图像的平均值
    average_precision_right_hip = np.mean(all_precisions_right_hip)
    average_recall_right_hip = np.mean(all_recalls_right_hip)
    average_f1_score_right_hip = np.mean(all_f1_scores_right_hip)

    average_precision_left_hip = np.mean(all_precisions_left_hip)
    average_recall_left_hip = np.mean(all_recalls_left_hip)
    average_f1_score_left_hip = np.mean(all_f1_scores_left_hip)

    # 打印单侧结果
    print("Right Hip Precision:", average_precision_right_hip)
    print("Right Hip Recall:", average_recall_right_hip)
    print("Right Hip F1 Score:", average_f1_score_right_hip)

    print("Left Hip Precision:", average_precision_left_hip)
    print("Left Hip Recall:", average_recall_left_hip)
    print("Left Hip F1 Score:", average_f1_score_left_hip)
    # ****************************************************************************************************
    # ****************************************************************************************************




    # 将所有角度结果转换为 DataFrame
    df = pd.DataFrame(results_degree)

    # 将DataFrame保存到Excel文件中
    excel_file = 'AIdegree_results.xlsx'
    df.to_excel(excel_file, index=False)
    print(f"Results saved to {excel_file}")





    # 指定要检查的文件夹路径
    source_folder = './data/coco2017/test'


    IHDI_1_R_pre = './data/coco2017/IHDI_1_R'
    IHDI_2_R_pre = './data/coco2017/IHDI_2_R'
    IHDI_3_R_pre = './data/coco2017/IHDI_3_R'
    IHDI_4_R_pre = './data/coco2017/IHDI_4_R'


    IHDI_1_L_pre = './data/coco2017/IHDI_1_L'
    IHDI_2_L_pre = './data/coco2017/IHDI_2_L'
    IHDI_3_L_pre = './data/coco2017/IHDI_3_L'
    IHDI_4_L_pre = './data/coco2017/IHDI_4_L'
    #
    #
    # 调用函数检查包含字母'a'的JPG文件
    # print("IHDI_1")
    normal_a_R,normal_b_R,normal_cd_R,normal_e_R,normal_R= count_images_with_1(source_folder,IHDI_1_R_pre,'q','w' , 'e', 'r')
    normal_x_L,normal_y_L,normal_zu_L,normal_v_L,normal_L = count_images_with_1(source_folder,IHDI_1_L_pre, 't','y' , 'u', 'i')
    # print(f"IHDI_2_R: {(normal_a_R / normal_R) * 100:.2f}%")
    # print(f"IHDI_2_L: {(normal_x_L / normal_L) * 100:.2f}%")
    # print("IHDI_2")
    kj_a_R,kj_b_R,kj_cd_R,kj_e_R,kj_R_true = count_images_with_2(source_folder,IHDI_2_R_pre, 'q','w' , 'e', 'r')
    kj_x_L,kj_y_L,kj_zu_L,kj_v_L,kj_L_true = count_images_with_2(source_folder,IHDI_2_L_pre, 't' , 'y', 'u', 'i')
    # print(f"IHDI_1_R: {(kj_b_R / kj_R_true) * 100:.2f}%")
    # print(f"IHDI_1_L: {(kj_y_L / kj_L_true) * 100:.2f}%")
    # print('****************************************************')
    # print("IHDI 3")
    mild_a_R,mild_b_R,mild_cd_R,mild_e_R,mild_R = count_images_with_3(source_folder,IHDI_3_R_pre, 'q','w' , 'e', 'r')
    mild_x_L,mild_y_L,mild_zu_L,mild_v_L,mild_L = count_images_with_3(source_folder,IHDI_3_L_pre, 't','y' , 'u', 'i')
    # print(f"IHDI_3_R: {(mild_cd_R / mild_R) * 100:.2f}%")
    # print(f"IHDI_3_L: {(mild_zu_L / mild_L) * 100:.2f}%")
    # print('****************************************************')
    # print("IHDI_4")
    heavy_a_R,heavy_b_R,heavy_cd_R,heavy_e_R,heavy_R = count_images_with_4(source_folder,IHDI_4_R_pre, 'q','w' , 'e', 'r')
    heavy_x_L,heavy_y_L,heavy_zu_L,heavy_v_L,heavy_L = count_images_with_4(source_folder,IHDI_4_L_pre, 't','y' , 'u', 'i')
    # print(f"IHDI_4_R: {(heavy_e_R / heavy_R) * 100:.2f}%")
    # print(f"IHDI_4_L: {(heavy_v_L / heavy_L) * 100:.2f}%")
    # print('****************************************************')



    # y_test为真实label，y_pred为预测label，classes为类别名称，是个ndarray数组，内容为string类型的标签
    labels_name = ['Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ']
    # 混淆矩阵数量R
    confusion_matrix = np.array([[int(normal_a_R)  , int(kj_a_R)  , int(mild_a_R)  , int(heavy_a_R)],
                                        [int(normal_b_R), int(kj_b_R), int(mild_b_R), int(heavy_b_R)],
                                        [  int(normal_cd_R) ,int(kj_cd_R) ,  int(mild_cd_R) ,  int(heavy_cd_R)],
                                        [  int(normal_e_R),  int(kj_e_R), int(mild_e_R)  , int(heavy_e_R)],
                                        ],dtype=np.float64)
    confusion_matrix_int = np.round(confusion_matrix).astype(int)

    plot_matrix(confusion_matrix_int, labels_name,pic_name = 'R.jpg')




    # 混淆矩阵数量L
    confusion_matrix = np.array([[int(normal_x_L)  , int(kj_x_L)  , int(mild_x_L)  , int(heavy_x_L)],
                                        [int(normal_y_L), int(kj_y_L), int(mild_y_L), int(heavy_y_L)],
                                        [  int(normal_zu_L) ,int(kj_zu_L) ,  int(mild_zu_L) ,  int(heavy_zu_L)],
                                        [  int(normal_v_L),  int(kj_v_L), int(mild_v_L)  , int(heavy_v_L)],
                                        ],dtype=np.float64)
    confusion_matrix_int = np.round(confusion_matrix).astype(int)
    plot_matrix(confusion_matrix_int, labels_name,pic_name = 'L.jpg')





    # 混淆矩阵百分比 R
    confusion_matrix = np.array([[normal_a_R, kj_a_R, mild_a_R, heavy_a_R],
                                        [normal_b_R, kj_b_R, mild_b_R, heavy_b_R],
                                        [normal_cd_R,kj_cd_R,mild_cd_R,heavy_cd_R],
                                        [normal_e_R, kj_e_R, mild_e_R, heavy_e_R],
                                        ], dtype=np.float64)
    # 使用 np.around() 函数将结果四舍五入到两位小数
    plot_matrix_percent(confusion_matrix, labels_name, pic_name='percent R.jpg')
    # , title='Diagnostic Results R'
    # # 百分比L

    confusion_matrix = np.array([[normal_x_L, kj_x_L, mild_x_L, heavy_x_L],
                                        [normal_y_L, kj_y_L, mild_y_L, heavy_y_L],
                                        [normal_zu_L, kj_zu_L, mild_zu_L, heavy_zu_L],
                                        [normal_v_L, kj_v_L, mild_v_L, heavy_v_L],
                                        ], dtype=np.float64)
    # 使用 np.around() 函数将结果四舍五入到两位小数
    plot_matrix_percent(confusion_matrix, labels_name, pic_name='percent L.jpg')




    # all
    confusion_matrix = np.array(
        [[int(normal_x_L + normal_a_R), int(kj_x_L + kj_a_R), int(mild_x_L +mild_a_R), int(heavy_x_L + heavy_a_R)],
                [int(normal_y_L+normal_b_R), int(kj_y_L+kj_b_R), int(mild_y_L+mild_b_R), int(heavy_y_L+heavy_b_R)],
                [int(normal_zu_L+normal_cd_R) ,int(kj_zu_L+kj_cd_R) ,  int(mild_zu_L+mild_cd_R) ,  int(heavy_zu_L+heavy_cd_R)],
                [int(normal_v_L+normal_e_R),  int(kj_v_L+kj_e_R), int(mild_v_L+mild_e_R)  , int(heavy_v_L+heavy_e_R)],
                ],dtype=np.float64)
    confusion_matrix_int = np.round(confusion_matrix).astype(int)
    plot_matrix(confusion_matrix_int, labels_name,pic_name = 'all.jpg')


    # all percent
    confusion_matrix = np.array(
        [[int(normal_x_L + normal_a_R), int(kj_x_L + kj_a_R), int(mild_x_L +mild_a_R), int(heavy_x_L + heavy_a_R)],
                [int(normal_y_L+normal_b_R), int(kj_y_L+kj_b_R), int(mild_y_L+mild_b_R), int(heavy_y_L+heavy_b_R)],
                [int(normal_zu_L+normal_cd_R) ,int(kj_zu_L+kj_cd_R) ,  int(mild_zu_L+mild_cd_R) ,  int(heavy_zu_L+heavy_cd_R)],
                [int(normal_v_L+normal_e_R),  int(kj_v_L+kj_e_R), int(mild_v_L+mild_e_R)  , int(heavy_v_L+heavy_e_R)],
                ],dtype=np.float64)
    plot_matrix_percent(confusion_matrix, labels_name,pic_name = 'percent all.jpg')




    # x 轴标签
    labels = ['A', 'B']
    #
    # 绘制柱状图
    plt.cla()
    # plt.bar(labels, means, yerr=errors, capsize=5)  # yerr 参数用于添加误差棒，capsize 用于指定误差棒的帽子大小
    # plt.xlabel('Groups')
    # plt.ylabel('Values')
    # plt.title('Bar chart with error bars')
    # plt.show()
    pic_name = 'mean_val.jpg'
    pic_mean = os.path.join('./data/coco2017/', pic_name)
    plt.savefig(pic_mean)



if __name__ == '__main__':
    predict_single_person()






















