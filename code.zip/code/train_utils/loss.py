import torch


class KpLoss(object):
    def __init__(self):
        self.criterion = torch.nn.MSELoss(reduction='none')  # 均方误差实例化

    # logits是网络预测的heatmap，target是利用GT信息构建的相关信息，包含了GT heatmap以及关键点的权重
    def __call__(self, logits, targets):
        assert len(logits.shape) == 4, 'logits should be 4-ndim'
        device = logits.device
        # 获取batch size
        bs = logits.shape[0]

        # heatmap：[num_kps, H, W] -> [B, num_kps, H, W]
        # target是一批数据，遍历每张图片的target，将heatmap拿出来，用stack方法拼接到一起
        heatmaps = torch.stack([t["heatmap"].to(device) for t in targets])

        # [num_kps] -> [B, num_kps]，同样提取关键点权重
        kps_weights = torch.stack([t["kps_weights"].to(device) for t in targets])

        # [B, num_kps, H, W] -> loss shape =[B, num_kps]
        # 计算均方误差
        loss = self.criterion(logits, heatmaps).mean(dim=[2, 3])    # h w
        # 各点loss乘上各点权重后求和，再除以batch个数，就的得到当前这批图片的平均损失
        loss = torch.sum(loss * kps_weights) / bs
        return loss
