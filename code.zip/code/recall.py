import numpy as np
import os

from PIL import Image
import json

import torch
import numpy as np
import cv2
import matplotlib.pyplot as plt
from torch.utils import data
from model import HighResolutionNet
from draw_utils import draw_keypoints
from heatmap import generate_heatmap,generate_ground_truth_heatmap
import transforms
from pycocotools.coco import COCO

img_path = 'img_path'
image_filename = 'image_filename'


file_name,image_path = getfilename(file_name,image_path)
def getfilename(file_name, image_path):
    file_name = file_name
    image_path = image_path
    return file_name, image_path

keypoints_pairs = []
truelabel_path = "data/coco2017/annotations/person_keypoints_testv.json"
# 读取JSON文件
with open(truelabel_path, 'r') as json_file:
    annotations_all = json.load(json_file)
coco = COCO(truelabel_path)
img_ids = list(sorted(coco.imgs.keys()))
det_json_path = None
if det_json_path is not None:
    det = coco.loadRes(det_json_path)
else:
    det = coco
valid_person_list = []
obj_idx = 0
for img_id in img_ids:
    img_info = coco.loadImgs(img_id)[0]
    ann_ids = det.getAnnIds(imgIds=img_id)
    anns = det.loadAnns(ann_ids)
    for ann in anns:
        # 只保存原coco数据集的person类标注
        # if ann["category_id"] != 1:
        #     print(f'warning: find not support id: {ann["category_id"]}, only support id: 1 (person)')
        #     continue

        # skip objs without keypoints annotation
        if "keypoints" not in ann:
            continue
        if max(ann["keypoints"]) == 0:
            continue

        xmin, ymin, w, h = ann['bbox']
        # Use only valid bounding boxes
        if w > 0 and h > 0:
            info = {
                "box": [xmin, ymin, w, h],
                "image_path": img_path,
                "image_id": img_id,
                "image_width": img_info['width'],
                "image_height": img_info['height'],
                "obj_origin_hw": [h, w],
                "obj_index": obj_idx,
                "score": ann["score"] if "score" in ann else 1.,
                # "file_name": img_info['file_name'],
            }
            image_id_pre = None
            # 查找特定图像文件名对应的图像ID
            image_id = None
            for image in annotations_all['images']:
                if image['file_name'] == image_filename:
                    image_id = image['id']
                    break

            # 根据找到的图像ID获取对应的关键点信息
            if image_id is not None:
                keypoints_info = next((item for item in annotations_all['annotations'] if item['image_id'] == image_id),
                                      None)
                if keypoints_info:
                    true_keypoints = keypoints_info['keypoints']
                    # keypoints_true = np.squeeze(keypoints_true)  # 关键点信息

                    for i in range(0, len(true_keypoints), 3):
                        x = true_keypoints[i]
                        y = true_keypoints[i + 1]
                        keypoints_pairs.append([x, y])

                    # print(f"Image ID: {image_id}, Keypoints: {true_keypoints}")

                else:
                    print("No keypoints found for the given image.")
            else:
                print("Given image file name not found in the dataset.")

print("Keypoints:", keypoints_pairs)
# keypoints_true[0][0]
# 获取真实标签的关键点坐标信息（假设已有）
true_keypoints = [keypoints_pairs[0],
                  keypoints_pairs[1],
                  keypoints_pairs[2],
                  keypoints_pairs[3],
                  keypoints_pairs[4],
                  keypoints_pairs[5],
                  keypoints_pairs[6],
                  keypoints_pairs[7]]  # 假设这里是真实标签的关键点坐标
print(true_keypoints)
def compute_precision_recall(true_keypoints, predicted_keypoints, threshold=1.0):
    true_positives = 0
    false_positives = 0
    false_negatives = 0

    for i in range(len(true_keypoints)):
        true_x, true_y = true_keypoints[i]
        predicted_x, predicted_y = predicted_keypoints[i]
        distance = np.sqrt((true_x - predicted_x) ** 2 + (true_y - predicted_y) ** 2)
        if distance <= threshold:
            true_positives += 1
        else:
            false_negatives += 1

    for i in range(len(predicted_keypoints)):
        predicted_x, predicted_y = predicted_keypoints[i]
        found_match = False
        for j in range(len(true_keypoints)):
            true_x, true_y = true_keypoints[j]
            distance = np.sqrt((true_x - predicted_x) ** 2 + (true_y - predicted_y) ** 2)
            if distance <= threshold:
                found_match = True
                break
        if not found_match:
            false_positives += 1

    precision = true_positives / (true_positives + false_positives)
    recall = true_positives / (true_positives + false_negatives)

    return precision, recall

def compute_mAP(true_keypoints, predicted_keypoints, threshold=1.0):
    precisions = []
    recalls = []
    for i in range(len(true_keypoints)):
        precision, recall = compute_precision_recall(true_keypoints[i], predicted_keypoints[i], threshold)
        precisions.append(precision)
        recalls.append(recall)
    return np.mean(precisions), np.mean(recalls)

def compute_F1(precision, recall):
    return 2 * precision * recall / (precision + recall)

# 假设这里是真实标签的关键点坐标
true_keypoints = [
    [[10, 20], [30, 40], [50, 60]],  # 示例真实标签的关键点坐标
    [[15, 25], [35, 45], [55, 65]]   # 示例真实标签的关键点坐标
]

# 假设这里是模型预测的关键点坐标
predicted_keypoints = [
    [[12, 22], [28, 38], [48, 58]],  # 示例模型预测的关键点坐标
    [[17, 27], [32, 42], [52, 62]]   # 示例模型预测的关键点坐标
]

# 计算精确率和召回率
precision, recall = compute_precision_recall(true_keypoints[0], predicted_keypoints[0])
print("Precision:", precision)
print("Recall:", recall)

# 计算mAP@0.5
mAP_05_precision, mAP_05_recall = compute_mAP(true_keypoints, predicted_keypoints, threshold=0.5)
print("mAP@0.5 Precision:", mAP_05_precision)
print("mAP@0.5 Recall:", mAP_05_recall)

# 计算mAP@0.5:0.95
mAP_05_095_precision, mAP_05_095_recall = compute_mAP(true_keypoints, predicted_keypoints, threshold=0.5)
print("mAP@0.5:0.95 Precision:", mAP_05_095_precision)
print("mAP@0.5:0.95 Recall:", mAP_05_095_recall)

# 计算F1值
F1 = compute_F1(precision, recall)
print("F1 Score:", F1)


