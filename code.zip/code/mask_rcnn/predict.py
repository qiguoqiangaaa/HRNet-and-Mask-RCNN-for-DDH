
import time
import json

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
from torchvision import transforms

from network_files import MaskRCNN
from backbone import resnet50_fpn_backbone
from draw_box_utils import draw_objs

from PIL import Image, ImageDraw, ImageFont
import os


def create_model(num_classes, box_thresh=0.5):
    backbone = resnet50_fpn_backbone()
    model = MaskRCNN(backbone,
                     num_classes=num_classes,
                     rpn_score_thresh=box_thresh,
                     box_score_thresh=box_thresh)

    return model


def time_synchronized():
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    return time.time()


def main():
    num_classes = 90  # 不包含背景
    box_thresh = 0.5
    weights_path = "./save_weights/model_209.pth"

    # weights_path = "./save_weights/model_true.pth"
    # img_path = "test.jpg"
    # 源文件夹路径，包含要批量处理的图片文件
    label_json_path = './coco91_indices.json'
    SEGA = './SEGOUT/SEGA'
    SEGF = './SEGOUT/SEGF'
    SEGA_original = './SEGOUT_original/SEGA_original'
    SEGF_original = './SEGOUT_original/SEGF_original'
    import shutil
    def delete_folder(folder_path):
        try:
            # 使用shutil.rmtree删除文件夹及其内容
            shutil.rmtree(folder_path)
            print(f"Successfully deleted the folder: {folder_path}")
        except Exception as e:
            print(f"An error occurred: {str(e)}")
    delete_folder(SEGA)
    delete_folder(SEGF)
    delete_folder(SEGA_original)
    delete_folder(SEGF_original)
    os.makedirs(SEGA, exist_ok=True)
    os.makedirs(SEGF, exist_ok=True)
    os.makedirs(SEGA_original, exist_ok=True)
    os.makedirs(SEGF_original, exist_ok=True)


    source_folder = '../data/coco2017/test'

    file_names = os.listdir(source_folder)

    # get devices
    device = torch.device("cuda:3" if torch.cuda.is_available() else "cpu")
    print("using {} device.".format(device))

    # create model
    model = create_model(num_classes=num_classes + 1, box_thresh=box_thresh)


    # load train weights
    assert os.path.exists(weights_path), "{} file dose not exist.".format(weights_path)
    weights_dict = torch.load(weights_path, map_location='cpu')
    weights_dict = weights_dict["model"] if "model" in weights_dict else weights_dict
    model.load_state_dict(weights_dict)
    model.to(device)

    # read class_indict
    assert os.path.exists(label_json_path), "json file {} dose not exist.".format(label_json_path)
    with open(label_json_path, 'r') as json_file:
        category_index = json.load(json_file)

    numberA = 0
    numberall = 0

    # 在循环外创建一个空的 DataFrame用于保存面积比与闭孔宽度比
    result_df = pd.DataFrame(columns=['Rr', 'area1', 'area2'])

    # 遍历每个文件名
    for file_name in file_names:
        numberall +=1
        # 构建源文件的完整路径
        source_file_path = os.path.join(source_folder, file_name)
        print(source_file_path)
        image_path = source_file_path  # 替换为你图片的路径
        img = Image.open(image_path)

        # load image
        assert os.path.exists(image_path), f"{image_path} does not exits."
        original_img = Image.open(image_path).convert('RGB')

        # from pil image to tensor, do not normalize image
        data_transform = transforms.Compose([transforms.ToTensor()])
        img = data_transform(original_img)
        # expand batch dimension
        img = torch.unsqueeze(img, dim=0)

        model.eval()  # 进入验证模式
        with torch.no_grad():
            # init
            img_height, img_width = img.shape[-2:]
            init_img = torch.zeros((1, 3, img_height, img_width), device=device)
            model(init_img)

            t_start = time_synchronized()
            predictions = model(img.to(device))[0]
            t_end = time_synchronized()
            print("inference+NMS time: {}".format(t_end - t_start))

            predict_boxes = predictions["boxes"].to("cpu").numpy()
            predict_classes = predictions["labels"].to("cpu").numpy()
            predict_scores = predictions["scores"].to("cpu").numpy()
            predict_mask = predictions["masks"].to("cpu").numpy()
            predict_mask = np.squeeze(predict_mask, axis=1)  # [batch, 1, h, w] -> [batch, h, w]

            # # ************像素面积
            # from skimage.measure import label, regionprops
            #
            # # 假设 predict_mask 包含所有目标的掩模
            #
            # # 使用 label 函数将掩模中的连通区域标记为不同的整数值
            # labeled_mask = label(predict_mask)
            # # 使用 regionprops 函数获取每个标记区域的属性
            # regions = regionprops(labeled_mask)
            # # 创建一个字典来存储每个目标的像素大小
            # object_mask_sizes = {}
            # # 遍历每个标记区域
            # for region in regions:
            #     # 获取当前区域的标记值
            #     label_value = region.label
            #     # 获取当前区域的非零像素数量
            #     pixel_count = region.area
            #     # 存储在字典中
            #     object_mask_sizes[label_value] = pixel_count
            # # 打印前四个最大目标的像素大小
            # # #这里使用了 sorted 函数，它返回一个按照字典值（像素大小）降序排列的元组列表。enumerate 用于获取列表中元素的索引，[:4] 用于截取前四个元素。
            # sorted_objects = sorted(object_mask_sizes.items(), key=lambda x: x[1], reverse=True)
            # # 获取前四个最大目标的像素大小
            # top_four_objects = sorted_objects[:4]
            # # 分别取出目标和像素大小
            # object1, size1 = top_four_objects[0]
            # object2, size2 = top_four_objects[1]
            # object3, size3 = top_four_objects[2]
            # object4, size4 = top_four_objects[3]



            plot_img, top_four_sizes = draw_objs(original_img,
                                 boxes=predict_boxes,
                                 classes=predict_classes,
                                 scores=predict_scores,
                                 masks=predict_mask,
                                 category_index=category_index,
                                 line_thickness=3,
                                 font='arial.ttf',
                                 font_size=20)

            print(top_four_sizes)
            # object1, size1, perimeter1= top_four_sizes[0]
            # object2, size2, perimeter2 = top_four_sizes[1]
            # object3, size3, perimeter3 = top_four_sizes[2]
            # object4, size4, perimeter4 = top_four_sizes[3]
            object1, size1, h1, w1, index_x1 = top_four_sizes[0]    # 髂骨
            object2, size2, h2, w2, index_x2 = top_four_sizes[1]
            object3, size3, h3, w3, index_x3 = top_four_sizes[2]    # 闭孔
            object4, size4, h4, w4, index_x4 = top_four_sizes[3]


            if index_x1 > index_x2:
                # 髂骨面积比
                area1 = size1 / size2
                # 髂骨旋转指数
                Rr_area1 = w1 / w2

            else:
                area1 = size2 / size1
                Rr_area1 = w2 / w1

            if index_x3 > index_x4:
                # 闭孔旋转指数
                Rr = w3 / w4
                # 闭孔面积比
                area2 = size3 / size4
            # 闭孔面积比
            else:
                Rr = w4 / w3
                area2 = size4 / size3

            plt.imshow(plot_img)
            # 在图像上绘制文本
            # 在图片上添加文本
            # plt.text(50, 50, f'Obturator Foramen Rotation Index: {Rr:.2f}', fontsize=10, color='blue')
            # plt.text(50, 100, f'Obturator Foramen Area Ratio: {area2:.2f}', fontsize=10, color='orange')
            # plt.text(50, 150, f'Ilium Rotation Index: {Rr_area1:.2f}', fontsize=10, color='red')
            # plt.text(50, 200, f'Ilium Area Ratio: {area1:.2f}', fontsize=10, color='green')


            # 显示
            # plt.show()

            # 设置阈值
            threshold1 = 0.8
            threshold2 = 0.8

            # 将当前结果追加到 DataFrame
            new_row = {'Rr_area1':Rr_area1,'Rr': Rr, 'area1': area1, 'area2': area2}
            result_df = pd.concat([result_df, pd.DataFrame([new_row])], ignore_index=True)
            # 保存当前结果到 Excel 文件
            result_df.to_excel('Rrarea.xlsx', index=False)
            # 分类

            # 假设 object1, size1, object2, size2 是你计算得到的前两个目标和它们的像素大小


            # 获取图像文件名
            file_name_original = os.path.basename(image_path)


            # 判断条件并保存图像到相应文件夹
            # if ( 0.75 <= Rr <= 1.45) and ( 0.75 <= area2 <= 1.45) and ( 0.71 <= Rr_area1 <= 1.22) and ( 0.71 <= area1 <= 1.22):
            if( 0.78 <= Rr <= 1.42)and ( 0.73 <= area2 <= 1.5)and ( 0.85 <= Rr_area1 <= 1.22) and ( 0.75 <= area1 <= 1.22):
                # 复制路径1
                SEGAout_original = os.path.join('./SEGOUT_original/SEGA_original', file_name_original)
                # 复制文件
                shutil.copy(image_path, SEGAout_original)
                AF = 'A'
                numberA += 1
            else:
                # 复制路径2
                SEGFout_original = os.path.join('./SEGOUT_original/SEGF_original', file_name_original)
                # 复制文件
                shutil.copy(image_path, SEGFout_original)
                AF = 'F'

            if AF == 'A':
                SEGAout = os.path.join(SEGA, file_name)
                print(SEGAout)
                # plot_img.save(SEGAout) # 无文本打印
                # 有文本打印
                plt.savefig(SEGAout)
                plt.cla()
            else:
                SEGFout = os.path.join(SEGF, file_name)
                print(SEGFout)
                # plot_img.save(SEGFout)
                # 有文本打印
                plt.savefig(SEGFout)
                plt.cla()

            # 保存预测的图片结果
            # if target_folder_R != None:
            #     target_file_path_R = os.path.join(target_folder_R, file_name)
            #     plt.savefig(target_file_path_R)

            # SEGAout = os.path.join(SEGA, file_name)
            # plt.savefig(SEGAout)
        print(numberall)
        print(numberA)

    def count_images_with_f(folder_path):
        # 获取文件夹中所有文件的列表
        files = os.listdir(folder_path)

        # 初始化计数器
        total_count = 0
        count_with_f = 0

        # 遍历文件列表
        for file_name in files:
            # 检查文件是否为图片（你可能需要根据实际情况扩展这个检查条件）
            if file_name.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                total_count += 1

                # 检查文件名中是否包含字母 'f'
                if 'f' in file_name.lower():
                    count_with_f += 1

        return total_count, count_with_f

    def count_images_notwith_f(folder_path):
        # 获取文件夹中所有文件的列表
        files = os.listdir(folder_path)

        # 初始化计数器
        total_count = 0
        count_with_f = 0

        # 遍历文件列表
        for file_name in files:
            # 检查文件是否为图片（你可能需要根据实际情况扩展这个检查条件）
            if file_name.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                total_count += 1

                # 检查文件名中是否包含字母 'f'
                if 'f' not in file_name.lower():
                    count_with_f += 1

        return total_count, count_with_f
    # 使用示例
    folder_path1 = './SEGOUT_original/SEGA_original'
    folder_path2 = './SEGOUT_original/SEGF_original'
    number1, f1 = count_images_with_f(folder_path1)     # 统计合格文件夹中，不合格图片的数量
    number2, f2 = count_images_notwith_f(folder_path2)  # 统计不合格文件夹中，合格图片的数量

    print(f"质控预测准确率为: {(1-(f1+f2)/(number1+number2)):.2%}")

# if ( 0.75 <= Rr <= 1.45) and ( 0.85 <= area1 <= 1.25) and ( 0.75 <= area2 <= 1.45):
# 质控预测准确率为: 7.31%
if __name__ == '__main__':
    main()

