import pandas as pd

# 读取 Excel 文件
df = pd.read_excel('name.xlsx')

# 打印 DataFrame 的列名
print(df.columns)
# 提取名字列数据
names = df['邰秋菊'].tolist()

# 统计名字的总数
total_names = len(names)

# 统计一共有多少人（重复的人名算一个人）
unique_names = set(names)
total_people = len(unique_names)

print("名字的总数：", total_names)
print("一共有多少人：", total_people)
