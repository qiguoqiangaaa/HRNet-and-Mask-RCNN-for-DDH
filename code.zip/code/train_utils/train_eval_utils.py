import math
import sys
import time

import torch

from model import HighResolutionNet
import transforms
import train_utils.distributed_utils as utils
from .coco_eval import EvalCOCOMetric
from .loss import KpLoss
from train import create_model

model = create_model(base_channel=32,num_joints=8)
class EMA():
    def __init__(self, model, decay):
        self.model = model
        self.decay = decay
        self.shadow = {}
        self.backup = {}

    def register(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = param.data.clone()

    def update(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.shadow
                new_average = (1.0 - self.decay) * param.data + self.decay * self.shadow[name]
                self.shadow[name] = new_average.clone()

    def apply_shadow(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.shadow
                self.backup[name] = param.data
                param.data = self.shadow[name]

    def restore(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.backup
                param.data = self.backup[name]
        self.backup = {}

ema = EMA(model, 0.999)   # ema 可以近似看成过去1/(1-decay)个时刻v值的平均
ema.register()
def train_one_epoch(model, optimizer, data_loader, device, epoch,
                    print_freq=50, warmup=False, scaler=None):
    model.train()   # 将模型设置为训练模式
    # 创建一个记录度量指标的工具，用于记录训练过程中的损失和其他指标
    metric_logger = utils.MetricLogger(delimiter="  ")
    # 为学习率添加一个记录器，用于记录学习率的变化
    metric_logger.add_meter('lr', utils.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    # 创建一个包含当前训练轮数的标题字符串，用于打印日志信息
    header = 'Epoch: [{}]'.format(epoch)

    lr_scheduler = None
    if epoch == 0 and warmup is True:  # 当训练第一轮（epoch=0）时，启用warmup训练方式，可理解为热身训练
        warmup_factor = 1.0 / 1000
        warmup_iters = min(1000, len(data_loader) - 1)

        lr_scheduler = utils.warmup_lr_scheduler(optimizer, warmup_iters, warmup_factor)

    # 均方误差（MSE）损失函数的实例
    mse = KpLoss()
    # 记录平均损失的张量，并将其移动到指定的设备上
    mloss = torch.zeros(1).to(device)  # mean losses

    # 迭代数据加载器中的批次数据  print_freq 是打印日志的频率，表示每经过多少个批次就打印一次日志信息。header 是用于打印日志的标题字符串
    # metric_logger.log_every() 是一个用于迭代数据加载器并在指定频率下记录日志的辅助函数。它返回一个迭代器，每次迭代会返回一个批次的图像数据和target
    # 通过使用 enumerate() 函数，可以获取每个批次的索引 i 和对应的图像数据 images 和targets。这样，可以在训练过程中对每个批次进行处理和训练模型
    for i, [images, targets] in enumerate(metric_logger.log_every(data_loader, print_freq, header)):
        # 将图像数据转换为张量，并将其移动到指定的设备上
        # [image.to(device) for image in images] 遍历批次中的每个图像，将每个图像数据 image 使用 .to(device) 方法将其移动到指定的设备。
        # 然后，通过 torch.stack() 函数将这些移动后的图像张量堆叠在一起，生成一个形状为 [batch_size, channels, height, width] 的张量 images。
        images = torch.stack([image.to(device) for image in images])

        # 混合精度训练上下文管理器，如果在CPU环境中不起任何作用
        with torch.cuda.amp.autocast(enabled=scaler is not None):
            results = model(images)     # 获得预测结果热图

            # 将网络预测的heatmap以及GT targets输入到KpLoss计算损失
            losses = mse(results, targets)

        # reduce losses over all GPUs for logging purpose 将损失值从多个GPU上进行约简，以便记录和日志输出
        loss_dict_reduced = utils.reduce_dict({"losses": losses})
        # 将约简后的损失值进行求和，得到总体的损失值
        losses_reduced = sum(loss for loss in loss_dict_reduced.values())

        loss_value = losses_reduced.item()
        # 记录训练损失（更新平均损失）
        # mloss * i 表示之前批次的累计平均损失值 * i。
        # + loss_value 表示当前批次的损失值。
        # / (i + 1) 表示总共有 (i + 1) 个批次的平均损失值。
        mloss = (mloss * i + loss_value) / (i + 1)  # update mean losses

        if not math.isfinite(loss_value):  # 当计算的损失为无穷大时停止训练
            print("Loss is {}, stopping training".format(loss_value))
            print(loss_dict_reduced)
            sys.exit(1)

        # 反向传播
        # 初始化
        optimizer.zero_grad()
        if scaler is not None:  # 如果使用混合精度训练
            scaler.scale(losses).backward()     # 使用自动混合精度缩放器 scaler 对损失进行反向传播
            scaler.step(optimizer)      # 使用缩放后的梯度更新优化器的参数
            scaler.update()             # 更新缩放器的比例因子，以确保下一次反向传播时使用正确的缩放比例
        else:   # 如果不使用混合精度训练
            losses.backward()   # 对损失进行反向传播
            optimizer.step()    # 更新优化器的参数

        if lr_scheduler is not None:  # 第一轮使用warmup训练方式
            lr_scheduler.step()

        metric_logger.update(loss=losses_reduced)       # 更新度量记录器，记录损失值
        now_lr = optimizer.param_groups[0]["lr"]        # 获取当前学习率
        metric_logger.update(lr=now_lr)                 # 更新度量记录器，记录学习率

        optimizer.step()
        ema.update()

    return mloss, now_lr


@torch.no_grad()
def evaluate(model, data_loader, device, flip=False, flip_pairs=None):
    ema.apply_shadow()
    # evaluate

    if flip:
        assert flip_pairs is not None, "enable flip must provide flip_pairs."

    model.eval()
    metric_logger = utils.MetricLogger(delimiter="  ")
    header = "Test: "

    key_metric = EvalCOCOMetric(data_loader.dataset.coco, "keypoints", "key_results.json")
    for image, targets in metric_logger.log_every(data_loader, 100, header):
        images = torch.stack([img.to(device) for img in image])

        # 当使用CPU时，跳过GPU相关指令
        if device != torch.device("cpu"):
            torch.cuda.synchronize(device)

        model_time = time.time()
        outputs = model(images)
        if flip:
            flipped_images = transforms.flip_images(images)
            flipped_outputs = model(flipped_images)
            flipped_outputs = transforms.flip_back(flipped_outputs, flip_pairs)
            # feature is not aligned, shift flipped heatmap for higher accuracy
            # https://github.com/leoxiaobin/deep-high-resolution-net.pytorch/issues/22
            flipped_outputs[..., 1:] = flipped_outputs.clone()[..., 0:-1]
            outputs = (outputs + flipped_outputs) * 0.5

        model_time = time.time() - model_time

        # decode keypoint
        reverse_trans = [t["reverse_trans"] for t in targets]
        outputs = transforms.get_final_preds(outputs, reverse_trans, post_processing=True)

        key_metric.update(targets, outputs)
        metric_logger.update(model_time=model_time)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)

    # 同步所有进程中的数据
    key_metric.synchronize_results()

    if utils.is_main_process():
        coco_info = key_metric.evaluate()
    else:
        coco_info = None

    ema.restore()

    return coco_info
